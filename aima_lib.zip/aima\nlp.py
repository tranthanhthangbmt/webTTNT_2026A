"""Natural Language Processing; Chart Parsing and PageRanking (Chapter 22-23)"""

from collections import defaultdict
from aima.utils import weighted_choice
from aima.search import Problem
import urllib.request
import copy
import heapq
import re


# ______________________________________________________________________________
# Grammars and Lexicons


def Rules(**rules):
    """Create a dictionary mapping symbols to alternative sequences.
    >>> Rules(A = "B C | D E")
    {'A': [['B', 'C'], ['D', 'E']]}
    """
    for (lhs, rhs) in rules.items():
        rules[lhs] = [alt.strip().split() for alt in rhs.split('|')]
    return rules


def Lexicon(**rules):
    """Create a dictionary mapping symbols to alternative words.
    >>> Lexicon(Article = "the | a | an")
    {'Article': ['the', 'a', 'an']}
    """
    for (lhs, rhs) in rules.items():
        rules[lhs] = [word.strip() for word in rhs.split('|')]
    return rules


class Grammar:
    """A context-free grammar defined by a set of rewrite rules and a lexicon.

    Rules map non-terminal categories to alternative right-hand sides, while the
    lexicon maps categories to the words that belong to them."""

    def __init__(self, name, rules, lexicon):
        """A grammar has a set of rules and a lexicon."""
        self.name = name
        self.rules = rules
        self.lexicon = lexicon
        self.categories = defaultdict(list)
        for lhs in lexicon:
            for word in lexicon[lhs]:
                self.categories[word].append(lhs)

    def rewrites_for(self, cat):
        """Return a sequence of possible rhs's that cat can be rewritten as."""
        return self.rules.get(cat, ())

    def isa(self, word, cat):
        """Return True iff word is of category cat"""
        return cat in self.categories[word]

    def cnf_rules(self):
        """Returns the tuple (X, Y, Z) for rules in the form:
        X -> Y Z"""
        cnf = []
        for X, rules in self.rules.items():
            for (Y, Z) in rules:
                cnf.append((X, Y, Z))

        return cnf

    def generate_random(self, S='S'):
        """Replace each token in S by a random entry in grammar (recursively)."""
        import random

        def rewrite(tokens, into):
            for token in tokens:
                if token in self.rules:
                    rewrite(random.choice(self.rules[token]), into)
                elif token in self.lexicon:
                    into.append(random.choice(self.lexicon[token]))
                else:
                    into.append(token)
            return into

        return ' '.join(rewrite(S.split(), []))

    def __repr__(self):
        return '<Grammar {}>'.format(self.name)


def ProbRules(**rules):
    """Create a dictionary mapping symbols to alternative sequences,
    with probabilities.
    >>> ProbRules(A = "B C [0.3] | D E [0.7]")
    {'A': [(['B', 'C'], 0.3), (['D', 'E'], 0.7)]}
    """
    for (lhs, rhs) in rules.items():
        rules[lhs] = []
        rhs_separate = [alt.strip().split() for alt in rhs.split('|')]
        for r in rhs_separate:
            prob = float(r[-1][1:-1])  # remove brackets, convert to float
            rhs_rule = (r[:-1], prob)
            rules[lhs].append(rhs_rule)

    return rules


def ProbLexicon(**rules):
    """Create a dictionary mapping symbols to alternative words,
    with probabilities.
    >>> ProbLexicon(Article = "the [0.5] | a [0.25] | an [0.25]")
    {'Article': [('the', 0.5), ('a', 0.25), ('an', 0.25)]}
    """
    for (lhs, rhs) in rules.items():
        rules[lhs] = []
        rhs_separate = [word.strip().split() for word in rhs.split('|')]
        for r in rhs_separate:
            prob = float(r[-1][1:-1])  # remove brackets, convert to float
            word = r[:-1][0]
            rhs_rule = (word, prob)
            rules[lhs].append(rhs_rule)

    return rules


class ProbGrammar:
    """A probabilistic context-free grammar.

    Like :class:`Grammar`, but every rule and lexicon entry carries a
    probability, so derivations can be sampled and scored by likelihood."""

    def __init__(self, name, rules, lexicon):
        """A grammar has a set of rules and a lexicon.
        Each rule has a probability."""
        self.name = name
        self.rules = rules
        self.lexicon = lexicon
        self.categories = defaultdict(list)

        for lhs in lexicon:
            for word, prob in lexicon[lhs]:
                self.categories[word].append((lhs, prob))

    def rewrites_for(self, cat):
        """Return a sequence of possible rhs's that cat can be rewritten as."""
        return self.rules.get(cat, ())

    def isa(self, word, cat):
        """Return True iff word is of category cat"""
        return cat in [c for c, _ in self.categories[word]]

    def cnf_rules(self):
        """Returns the tuple (X, Y, Z, p) for rules in the form:
        X -> Y Z [p]"""
        cnf = []
        for X, rules in self.rules.items():
            for (Y, Z), p in rules:
                cnf.append((X, Y, Z, p))

        return cnf

    def generate_random(self, S='S'):
        """Replace each token in S by a random entry in grammar (recursively).
        Returns a tuple of (sentence, probability)."""
        import random

        def rewrite(tokens, into):
            for token in tokens:
                if token in self.rules:
                    non_terminal, prob = weighted_choice(self.rules[token])
                    into[1] *= prob
                    rewrite(non_terminal, into)
                elif token in self.lexicon:
                    terminal, prob = weighted_choice(self.lexicon[token])
                    into[0].append(terminal)
                    into[1] *= prob
                else:
                    into[0].append(token)
            return into

        rewritten_as, prob = rewrite(S.split(), [[], 1])
        return (' '.join(rewritten_as), prob)

    def __repr__(self):
        return '<Grammar {}>'.format(self.name)


E0 = Grammar('E0',
             Rules(  # Grammar for E_0 [Figure 22.4]
                 S='NP VP | S Conjunction S',
                 NP='Pronoun | Name | Noun | Article Noun | Digit Digit | NP PP | NP RelClause',
                 VP='Verb | VP NP | VP Adjective | VP PP | VP Adverb',
                 PP='Preposition NP',
                 RelClause='That VP'),

             Lexicon(  # Lexicon for E_0 [Figure 22.3]
                 Noun="stench | breeze | glitter | nothing | wumpus | pit | pits | gold | east",
                 Verb="is | see | smell | shoot | fell | stinks | go | grab | carry | kill | turn | feel",  # noqa
                 Adjective="right | left | east | south | back | smelly",
                 Adverb="here | there | nearby | ahead | right | left | east | south | back",
                 Pronoun="me | you | I | it",
                 Name="John | Mary | Boston | Aristotle",
                 Article="the | a | an",
                 Preposition="to | in | on | near",
                 Conjunction="and | or | but",
                 Digit="0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9",
                 That="that"
             ))

E_ = Grammar('E_',  # Trivial Grammar and lexicon for testing
             Rules(
                 S='NP VP',
                 NP='Art N | Pronoun',
                 VP='V NP'),

             Lexicon(
                 Art='the | a',
                 N='man | woman | table | shoelace | saw',
                 Pronoun='I | you | it',
                 V='saw | liked | feel'
             ))

E_NP_ = Grammar('E_NP_',  # Another Trivial Grammar for testing
                Rules(NP='Adj NP | N'),
                Lexicon(Adj='happy | handsome | hairy',
                        N='man'))

E_Prob = ProbGrammar('E_Prob',  # The Probabilistic Grammar from the notebook
                     ProbRules(
                         S="NP VP [0.6] | S Conjunction S [0.4]",
                         NP="Pronoun [0.2] | Name [0.05] | Noun [0.2] | Article Noun [0.15] \
                             | Article Adjs Noun [0.1] | Digit [0.05] | NP PP [0.15] | NP RelClause [0.1]",
                         VP="Verb [0.3] | VP NP [0.2] | VP Adjective [0.25] | VP PP [0.15] | VP Adverb [0.1]",
                         Adjs="Adjective [0.5] | Adjective Adjs [0.5]",
                         PP="Preposition NP [1]",
                         RelClause="RelPro VP [1]"
                     ),
                     ProbLexicon(
                         Verb="is [0.5] | say [0.3] | are [0.2]",
                         Noun="robot [0.4] | sheep [0.4] | fence [0.2]",
                         Adjective="good [0.5] | new [0.2] | sad [0.3]",
                         Adverb="here [0.6] | lightly [0.1] | now [0.3]",
                         Pronoun="me [0.3] | you [0.4] | he [0.3]",
                         RelPro="that [0.5] | who [0.3] | which [0.2]",
                         Name="john [0.4] | mary [0.4] | peter [0.2]",
                         Article="the [0.5] | a [0.25] | an [0.25]",
                         Preposition="to [0.4] | in [0.3] | at [0.3]",
                         Conjunction="and [0.5] | or [0.2] | but [0.3]",
                         Digit="0 [0.35] | 1 [0.35] | 2 [0.3]"
                     ))

E_Chomsky = Grammar('E_Prob_Chomsky',  # A Grammar in Chomsky Normal Form
                    Rules(
                        S='NP VP',
                        NP='Article Noun | Adjective Noun',
                        VP='Verb NP | Verb Adjective',
                    ),
                    Lexicon(
                        Article='the | a | an',
                        Noun='robot | sheep | fence',
                        Adjective='good | new | sad',
                        Verb='is | say | are'
                    ))

E_Prob_Chomsky = ProbGrammar('E_Prob_Chomsky',  # A Probabilistic Grammar in CNF
                             ProbRules(
                                 S='NP VP [1]',
                                 NP='Article Noun [0.6] | Adjective Noun [0.4]',
                                 VP='Verb NP [0.5] | Verb Adjective [0.5]',
                             ),
                             ProbLexicon(
                                 Article='the [0.5] | a [0.25] | an [0.25]',
                                 Noun='robot [0.4] | sheep [0.4] | fence [0.2]',
                                 Adjective='good [0.5] | new [0.2] | sad [0.3]',
                                 Verb='is [0.5] | say [0.3] | are [0.2]'
                             ))
E_Prob_Chomsky_ = ProbGrammar('E_Prob_Chomsky_',
                              ProbRules(
                                  S='NP VP [1]',
                                  NP='NP PP [0.4] | Noun Verb [0.6]',
                                  PP='Preposition NP [1]',
                                  VP='Verb NP [0.7] | VP PP [0.3]',
                              ),
                              ProbLexicon(
                                  Noun='astronomers [0.18] | eyes [0.32] | stars [0.32] | telescopes [0.18]',
                                  Verb='saw [0.5] | \'\' [0.5]',
                                  Preposition='with [1]'
                              ))


# ______________________________________________________________________________
# Chart Parsing


class Chart:
    """Class for parsing sentences using a chart data structure.
    >>> chart = Chart(E0)
    >>> len(chart.parses('the stench is in 2 2'))
    1
    """

    def __init__(self, grammar, trace=False):
        """A datastructure for parsing a string; and methods to do the parse.
        self.chart[i] holds the edges that end just before the i'th word.
        Edges are 5-element lists of [start, end, lhs, [found], [expects]]."""
        self.grammar = grammar
        self.trace = trace

    def parses(self, words, S='S'):
        """Return a list of parses; words can be a list or string."""
        if isinstance(words, str):
            words = words.split()
        self.parse(words, S)
        # Return all the parses that span the whole input
        # 'span the whole input' => begin at 0, end at len(words)
        return [[i, j, S, found, []]
                for (i, j, lhs, found, expects) in self.chart[len(words)]
                # assert j == len(words)
                if i == 0 and lhs == S and expects == []]

    def parse(self, words, S='S'):
        """Parse a list of words; according to the grammar.
        Leave results in the chart."""
        self.chart = [[] for i in range(len(words) + 1)]
        self.add_edge([0, 0, 'S_', [], [S]])
        for i in range(len(words)):
            self.scanner(i, words[i])
        return self.chart

    def add_edge(self, edge):
        """Add edge to chart, and see if it extends or predicts another edge."""
        start, end, lhs, found, expects = edge
        if edge not in self.chart[end]:
            self.chart[end].append(edge)
            if self.trace:
                print('Chart: added {}'.format(edge))
            if not expects:
                self.extender(edge)
            else:
                self.predictor(edge)

    def scanner(self, j, word):
        """For each edge expecting a word of this category here, extend the edge."""
        for (i, j, A, alpha, Bb) in self.chart[j]:
            if Bb and self.grammar.isa(word, Bb[0]):
                self.add_edge([i, j + 1, A, alpha + [(Bb[0], word)], Bb[1:]])

    def predictor(self, edge):
        """Add to chart any rules for B that could help extend this edge."""
        (i, j, A, alpha, Bb) = edge
        B = Bb[0]
        if B in self.grammar.rules:
            for rhs in self.grammar.rewrites_for(B):
                self.add_edge([j, j, B, [], rhs])

    def extender(self, edge):
        """See what edges can be extended by this edge."""
        (j, k, B, _, _) = edge
        for (i, j, A, alpha, B1b) in self.chart[j]:
            if B1b and B == B1b[0]:
                self.add_edge([i, k, A, alpha + [edge], B1b[1:]])


# ______________________________________________________________________________
# CYK Parsing

def CYK_parse(words, grammar):
    """ [Figure 23.5] """
    # We use 0-based indexing instead of the book's 1-based.
    N = len(words)
    P = defaultdict(float)

    # Insert lexical rules for each word.
    for (i, word) in enumerate(words):
        for (X, p) in grammar.categories[word]:
            P[X, i, 1] = p

    # Combine first and second parts of right-hand sides of rules,
    # from short to long.
    for length in range(2, N + 1):
        for start in range(N - length + 1):
            for len1 in range(1, length):  # N.B. the book incorrectly has N instead of length
                len2 = length - len1
                for (X, Y, Z, p) in grammar.cnf_rules():
                    P[X, start, length] = max(P[X, start, length],
                                              P[Y, start, len1] * P[Z, start + len1, len2] * p)

    return P


class Tree:
    """A simple parse-tree node with a root label and a list of child leaves
    (which may themselves be subtrees), as built by CYK parsing."""

    def __init__(self, root, *args):
        self.root = root
        self.leaves = [leaf for leaf in args]


def subspan(N):
    """returns all tuple(i, j, k) covering a span (i, k) with i <= j < k"""
    for length in range(2, N + 1):
        for i in range(1, N + 2 - length):
            k = i + length - 1
            for j in range(i, k):
                yield (i, j, k)


# ______________________________________________________________________________
# Text Parsing using Search


class TextParsingProblem(Problem):
    """A search problem that parses a list of words bottom-up into a goal symbol.

    States are partially-reduced word/category sequences; actions replace words
    with their lexical categories and replace spans of categories by the rules
    that produce them, so that a solution path corresponds to a valid parse."""

    def __init__(self, initial, grammar, goal='S'):
        """
        :param initial: the initial state of words in a list.
        :param grammar: a grammar object
        :param goal: the goal state, usually S
        """
        super(TextParsingProblem, self).__init__(initial, goal)
        self.grammar = grammar
        self.combinations = defaultdict(list)  # article combinations
        # backward lookup of rules
        for rule in grammar.rules:
            for comb in grammar.rules[rule]:
                self.combinations[' '.join(comb)].append(rule)

    def actions(self, state):
        """Return the successor states reachable from ``state``: first replace each
        word by each of its lexical categories, and once only categories remain
        replace spans that match a grammar rule's right-hand side by that rule."""
        actions = []
        categories = self.grammar.categories
        # first change each word to the article of its category
        for i in range(len(state)):
            word = state[i]
            if word in categories:
                for X in categories[word]:
                    state[i] = X
                    actions.append(copy.copy(state))
                    state[i] = word
        # if all words are replaced by articles, replace combinations of articles by inferring rules.
        if not actions:
            for start in range(len(state)):
                for end in range(start, len(state) + 1):
                    # try combinations between (start, end)
                    articles = ' '.join(state[start:end])
                    for c in self.combinations[articles]:
                        actions.append(state[:start] + [c] + state[end:])
        return actions

    def result(self, state, action):
        """Return the state resulting from applying ``action`` (the action is itself
        the already-computed successor state)."""
        return action

    def h(self, state):
        """Heuristic estimating remaining cost as the number of symbols still left
        to reduce in ``state``."""
        # heuristic function
        return len(state)


def astar_search_parsing(words, gramma):
    """bottom-up parsing using A* search to find whether a list of words is a sentence"""
    # init the problem
    problem = TextParsingProblem(words, gramma, 'S')
    state = problem.initial
    # init the searching frontier
    frontier = [(len(state) + problem.h(state), state)]
    heapq.heapify(frontier)

    while frontier:
        # search the frontier node with lowest cost first
        cost, state = heapq.heappop(frontier)
        actions = problem.actions(state)
        for action in actions:
            new_state = problem.result(state, action)
            # update the new frontier node to the frontier
            if new_state == [problem.goal]:
                return problem.goal
            if new_state != state:
                heapq.heappush(frontier, (len(new_state) + problem.h(new_state), new_state))
    return False


def beam_search_parsing(words, gramma, b=3):
    """bottom-up text parsing using beam search"""
    # init problem
    problem = TextParsingProblem(words, gramma, 'S')
    # init frontier
    frontier = [(len(problem.initial), problem.initial)]
    heapq.heapify(frontier)

    # explore the current frontier and keep b new states with lowest cost
    def explore(frontier):
        new_frontier = []
        for cost, state in frontier:
            # expand the possible children states of current state
            if not problem.goal_test(' '.join(state)):
                actions = problem.actions(state)
                for action in actions:
                    new_state = problem.result(state, action)
                    if [len(new_state), new_state] not in new_frontier and new_state != state:
                        new_frontier.append([len(new_state), new_state])
            else:
                return problem.goal
        heapq.heapify(new_frontier)
        # only keep b states
        return heapq.nsmallest(b, new_frontier)

    while frontier:
        frontier = explore(frontier)
        if frontier == problem.goal:
            return frontier
    return False


# ______________________________________________________________________________
# Page Ranking

# First entry in list is the base URL, and then following are relative URL pages
example_pages_set = ["https://en.wikipedia.org/wiki/", "Aesthetics", "Analytic_philosophy",
                   "Ancient_Greek", "Aristotle", "Astrology", "Atheism", "Baruch_Spinoza",
                   "Belief", "Betrand Russell", "Confucius", "Consciousness",
                   "Continental Philosophy", "Dialectic", "Eastern_Philosophy",
                   "Epistemology", "Ethics", "Existentialism", "Friedrich_Nietzsche",
                   "Idealism", "Immanuel_Kant", "List_of_political_philosophers", "Logic",
                   "Metaphysics", "Philosophers", "Philosophy", "Philosophy_of_mind", "Physics",
                   "Plato", "Political_philosophy", "Pythagoras", "Rationalism",
                   "Social_philosophy", "Socrates", "Subjectivity", "Theology",
                   "Truth", "Western_philosophy"]


def load_page_html(address_list):
    """Download HTML page content for every URL address passed as argument"""
    content_dict = {}
    for addr in address_list:
        with urllib.request.urlopen(addr) as response:
            raw_html = response.read().decode('utf-8')
            # Strip raw html of unnecessary content. Basically everything that isn't link or text
            html = strip_raw_html(raw_html)
            content_dict[addr] = html
    return content_dict


def init_pages(address_list):
    """Create a dictionary of pages from a list of URL addresses"""
    pages = {}
    for addr in address_list:
        pages[addr] = Page(addr)
    return pages


def strip_raw_html(raw_html):
    """Remove the <head> section of the HTML which contains links to stylesheets etc.,
    and remove all other unnecessary HTML"""
    # TODO: Strip more out of the raw html
    return re.sub("<head>.*?</head>", "", raw_html, flags=re.DOTALL)  # remove <head> section


def determine_inlinks(page):
    """Given a set of pages that have their outlinks determined, we can fill
    out a page's inlinks by looking through all other page's outlinks"""
    inlinks = []
    for addr, index_page in pages_index.items():
        if page.address == index_page.address:
            continue
        elif page.address in index_page.outlinks:
            inlinks.append(addr)
    return inlinks


def find_outlinks(page, handle_urls=None):
    """Search a page's HTML content for URL links to other pages"""
    urls = re.findall(r'href=[\'"]?([^\'" >]+)', pages_content[page.address])
    if handle_urls:
        urls = handle_urls(urls)
    return urls


def only_wikipedia_urls(urls):
    """Some example HTML page data is from wikipedia. This function converts
    relative wikipedia links to full wikipedia URLs"""
    wiki_urls = [url for url in urls if url.startswith('/wiki/')]
    return ["https://en.wikipedia.org" + url for url in wiki_urls]


# ______________________________________________________________________________
# HITS Helper Functions

def expand_pages(pages):
    """Adds in every page that links to or is linked from one of
    the relevant pages."""
    expanded = {}
    for addr, page in pages.items():
        if addr not in expanded:
            expanded[addr] = page
        for inlink in page.inlinks:
            if inlink not in expanded:
                expanded[inlink] = pages_index[inlink]
        for outlink in page.outlinks:
            if outlink not in expanded:
                expanded[outlink] = pages_index[outlink]
    return expanded


def relevant_pages(query):
    """Relevant pages are pages that contain all of the query words. They are obtained by
    intersecting the hit lists of the query words."""
    hit_intersection = {addr for addr in pages_index}
    query_words = query.split()
    for query_word in query_words:
        hit_list = set()
        for addr in pages_index:
            if query_word.lower() in pages_content[addr].lower():
                hit_list.add(addr)
        hit_intersection = hit_intersection.intersection(hit_list)
    return {addr: pages_index[addr] for addr in hit_intersection}


def normalize(pages):
    """Normalize divides each page's score by the sum of the squares of all
    pages' scores (separately for both the authority and hub scores).
    """
    summed_hub = sum(page.hub ** 2 for _, page in pages.items())
    summed_auth = sum(page.authority ** 2 for _, page in pages.items())
    for _, page in pages.items():
        page.hub /= summed_hub ** 0.5
        page.authority /= summed_auth ** 0.5


class ConvergenceDetector(object):
    """If the hub and authority values of the pages are no longer changing, we have
    reached a convergence and further iterations will have no effect. This detects convergence
    so that we can stop the HITS algorithm as early as possible."""

    def __init__(self):
        self.hub_history = None
        self.auth_history = None

    def __call__(self):
        return self.detect()

    def detect(self):
        """Return True once the average change in hub and authority values across all
        indexed pages falls below the convergence threshold, otherwise False."""
        curr_hubs = [page.hub for addr, page in pages_index.items()]
        curr_auths = [page.authority for addr, page in pages_index.items()]
        if self.hub_history is None:
            self.hub_history, self.auth_history = [], []
        else:
            diffs_hub = [abs(x - y) for x, y in zip(curr_hubs, self.hub_history[-1])]
            diffs_auth = [abs(x - y) for x, y in zip(curr_auths, self.auth_history[-1])]
            ave_delta_hub = sum(diffs_hub) / float(len(pages_index))
            ave_delta_auth = sum(diffs_auth) / float(len(pages_index))
            if ave_delta_hub < 0.01 and ave_delta_auth < 0.01:  # may need tweaking
                return True
        if len(self.hub_history) > 2:  # prevent list from getting long
            del self.hub_history[0]
            del self.auth_history[0]
        self.hub_history.append([x for x in curr_hubs])
        self.auth_history.append([x for x in curr_auths])
        return False


def get_in_links(page):
    """Return the addresses of indexed pages that link into the given page."""
    if not page.inlinks:
        page.inlinks = determine_inlinks(page)
    return [addr for addr, p in pages_index.items() if addr in page.inlinks]


def get_out_links(page):
    """Return the addresses of indexed pages that the given page links out to."""
    if not page.outlinks:
        page.outlinks = find_outlinks(page)
    return [addr for addr, p in pages_index.items() if addr in page.outlinks]


# ______________________________________________________________________________
# HITS Algorithm

class Page(object):
    """A web page used by the HITS algorithm, holding its address, inbound and
    outbound links, and its current hub and authority scores."""

    def __init__(self, address, in_links=None, out_links=None, hub=0, authority=0):
        self.address = address
        self.hub = hub
        self.authority = authority
        self.inlinks = in_links
        self.outlinks = out_links


pages_content = {}  # maps Page relative or absolute URL/location to page's HTML content
pages_index = {}
convergence = ConvergenceDetector()  # assign function to variable to mimic pseudocode's syntax


def HITS(query):
    """The HITS algorithm for computing hubs and authorities with respect to a query."""
    pages = expand_pages(relevant_pages(query))
    for p in pages.values():
        p.authority = 1
        p.hub = 1
    while not convergence():
        authority = {p: pages[p].authority for p in pages}
        hub = {p: pages[p].hub for p in pages}
        for p in pages:
            # p.authority ← ∑i Inlinki(p).Hub
            pages[p].authority = sum(hub[x] for x in get_in_links(pages[p]))
            # p.hub ← ∑i Outlinki(p).Authority
            pages[p].hub = sum(authority[x] for x in get_out_links(pages[p]))
        normalize(pages)
    return pages
